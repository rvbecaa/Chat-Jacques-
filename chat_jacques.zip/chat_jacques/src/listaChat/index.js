import React, { useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet, Text, TouchableOpacity, View, Image, ActivityIndicator } from 'react-native';
import { firestore, auth } from '../../firebase'; // Firebase configuration
import { collection, getDocs } from 'firebase/firestore';
import { useNavigation } from '@react-navigation/native';
import { onAuthStateChanged } from 'firebase/auth';

const whatsImage = require('../../assets/whats.webp');

const Chats = () => {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null); // Para armazenar o usuário logado
  const [loading, setLoading] = useState(true); // Estado para controle de carregamento
  const navigation = useNavigation();

  // Monitorando o estado de autenticação do Firebase
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);  // Atualiza o usuário logado
      } else {
        setCurrentUser(null);  // Se não estiver logado, define como null
      }
    });

    return () => unsubscribe(); // Cleanup ao desmontar o componente
  }, []);

  useEffect(() => {
    const fetchUsers = async () => {
      if (!currentUser) return; // Se não houver usuário logado, não faz nada

      try {
        setLoading(true); // Inicia o carregamento
        const querySnapshot = await getDocs(collection(firestore, 'users'));
        const usersData = querySnapshot.docs
          .map(doc => ({ ...doc.data(), id: doc.id }))
          .filter(user => user.id !== currentUser.uid); // Filtrando o próprio usuário logado

        setUsers(usersData);
      } catch (error) {
        console.error('Erro ao carregar usuários: ', error);
      } finally {
        setLoading(false); // Finaliza o carregamento
      }
    };

    fetchUsers();
  }, [currentUser]);

  const startChat = (user) => {
    // Navegar para a tela de chat com o usuário selecionado
    navigation.navigate('ChatDetails', { user });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Image source={whatsImage} style={styles.image} />
        {currentUser && (
          <Text style={styles.userLogged}>Bem-vindo, {currentUser.displayName}</Text>
        )}
      </View>

      <Text style={styles.title}>Usuários</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#3fab4e" />
      ) : (
        users.map(user => (
          <TouchableOpacity
            key={user.id}
            style={styles.userItem}
            onPress={() => startChat(user)}
          >
            <Text style={styles.userName}>{user.name}</Text>
            <Text style={styles.userEmail}>{user.email}</Text>
          </TouchableOpacity>
        ))
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#42f563',
    padding: 20,
  },
  header: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 20,
  },
  image: {
    width: 80,
    height: 80,
    marginBottom: 10,
  },
  userLogged: {
    fontSize: 18,
    fontWeight: '600',
    color: 'white',
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    marginTop: 32,
    color: 'white',
  },
  userItem: {
    marginVertical: 8,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    width: '100%',
    marginHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  userEmail: {
    fontSize: 14,
    color: '#555',
  },
});

export default Chats;
