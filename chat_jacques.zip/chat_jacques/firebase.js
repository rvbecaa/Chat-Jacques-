// Importando o SDK do Firebase
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDNIud3k3Blv6LD1xtdY79WIjmqPDCUuZM",
  authDomain: "chat-88deb.firebaseapp.com",
  projectId: "chat-88deb",
  storageBucket: "chat-88deb.firebasestorage.app",
  messagingSenderId: "939444987516",
  appId: "1:939444987516:web:57a44255a76a736e3e8bf9",
  measurementId: "G-CNHV5GQXJC"
};

// Inicializando o Firebase
const app = initializeApp(firebaseConfig);

// Inicializando os serviços necessários
const auth = getAuth(app);
const firestore = getFirestore(app);
const database = getDatabase(app);

// Exportando as referências
export { auth, firestore, database };
