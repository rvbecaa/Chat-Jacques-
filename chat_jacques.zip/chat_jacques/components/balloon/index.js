import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const Balloon = ({ message, currentUser }) => {
  const isCurrentUser = message.sentBy === currentUser;

  return (
    <View
      style={[
        styles.bubble,
        isCurrentUser ? styles.currentUser : styles.otherUser,
      ]}
    >
      <Text
        style={isCurrentUser ? styles.currentUserText : styles.otherUserText}
      >
        {message.content}
      </Text>
      {message.image && (
        <Image
          source={{ uri: message.image }}
          style={styles.image}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  bubble: {
    padding: 10,
    borderRadius: 15,
    marginVertical: 5,
    maxWidth: '80%',
    flexDirection: 'column', // Assegurando que o texto e a imagem se alinhem em coluna
    alignItems: 'flex-start', // Alinha o conteúdo à esquerda por padrão
  },
  currentUser: {
    backgroundColor: '#21612a', // Verde escuro para o usuário atual
    alignSelf: 'flex-end', // Mensagens do usuário atual alinhadas à direita
    borderBottomRightRadius: 0, // Evita arredondamento na parte inferior direita
  },
  otherUser: {
    backgroundColor: '#e5e5ea', // Cor padrão para outros usuários
    alignSelf: 'flex-start', // Mensagens de outros usuários alinhadas à esquerda
    borderBottomLeftRadius: 0, // Evita arredondamento na parte inferior esquerda
  },
  currentUserText: {
    color: 'white', // Texto branco para as mensagens enviadas
    fontSize: 16, // Aumentando o tamanho da fonte para 16
    maxWidth: '90%', // Limitando a largura do texto
    lineHeight: 22, // Ajustando o espaçamento entre as linhas
  },
  otherUserText: {
    color: 'black', // Texto preto para as mensagens de outros usuários
    fontSize: 16, // Aumentando o tamanho da fonte para 16
    maxWidth: '90%', // Limitando a largura do texto
    lineHeight: 22, // Ajustando o espaçamento entre as linhas
  },
  image: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginTop: 5,
    alignSelf: 'center', // Centralizando a imagem
  },
});

export default Balloon;
