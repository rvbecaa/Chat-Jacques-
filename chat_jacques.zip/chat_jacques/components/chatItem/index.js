import React from 'react';
import { Image, StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import UserDefaultImage from '../../assets/user.png';

const styles = StyleSheet.create({
  chatItemContainer: {
    flexDirection: 'row',
    marginVertical: 16,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd', // Linha de separação sutil
  },
  userPairImage: {
    width: 48,
    height: 48,
    borderRadius: 24, // Tornando a imagem circular
    marginRight: 16,
  },
  chatInfoContainer: {
    flex: 1, // Faz o texto ocupar o restante da largura disponível
  },
  userPairPhone: {
    fontWeight: '600',
    fontSize: 16, // Tamanho um pouco maior para o nome
    color: '#333', // Cor mais forte para o nome do usuário
    marginBottom: 6,
  },
  chatLastMessage: {
    fontWeight: '300',
    color: '#999',
    fontSize: 14, // Ajuste de tamanho para não sobrecarregar
    marginBottom: 8, // Espaço abaixo da última mensagem
  },
  actionButton: {
    marginTop: 6,
    backgroundColor: '#21612a', // Botão verde escuro
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  container: {
    marginTop: 16,
    marginHorizontal: 16,
  },
});

const ChatItem = ({ chat, currentUser, onPress }) => {
  const [userPair] = chat.users.filter((u) => u.id !== currentUser);

  return (
    <View style={styles.chatItemContainer}>
      <Image source={UserDefaultImage} style={styles.userPairImage} />
      <View style={styles.chatInfoContainer}>
        <Text style={styles.userPairPhone}>{userPair.phone}</Text>
        <Text style={styles.chatLastMessage}>
          {chat.messages[chat.messages.length - 1]?.content || "Sem mensagens"}
        </Text>
        <TouchableOpacity style={styles.actionButton} onPress={onPress}>
          <Text style={styles.actionButtonText}>Ir para o chat</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ChatItem;
