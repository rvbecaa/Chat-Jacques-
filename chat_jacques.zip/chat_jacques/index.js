import { registerRootComponent } from 'expo';
import App from './App';

// Registrar o componente principal
registerRootComponent(App);
